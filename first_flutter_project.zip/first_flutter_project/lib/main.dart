import 'package:flutter/material.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.red,
      ),
      home: Logo(),
    
    );
  }
}

class Logo extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
          decoration: BoxDecoration(
            image: DecorationImage(
              image: AssetImage('assets/images/frame1.png'),
              fit: BoxFit.none,
            )
          ),
          child: Center(
          child: Image(
            image: AssetImage('assets/images/Logo_tagline.png'),
            fit: BoxFit.scaleDown,
            height: 300,
          ),
        ),  
      ),  
    );
  }
}