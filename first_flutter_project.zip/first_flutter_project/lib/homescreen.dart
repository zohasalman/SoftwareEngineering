import 'package:flutter/material.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.red,
      ),
      home: Logo(),
    );
  }
}

class Logo extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('hi'),
        backgroundColor: new Color(0xFF24292E),
      ),
      body: Image.asset('assets/images/12.jpeg'),
      // body: Column(
      //   crossAxisAlignment: CrossAxisAlignment.start,
      //   mainAxisSize: MainAxisSize.max,
      //   mainAxisAlignment: MainAxisAlignment.start,
      //   children: <Widget>[
      //     Image.asset(
      //       'assets/images/Logo with tagline.png', width: 100.0, height: 100.0,
      //     ),
      //   ],
      // ),
    );
  }
}